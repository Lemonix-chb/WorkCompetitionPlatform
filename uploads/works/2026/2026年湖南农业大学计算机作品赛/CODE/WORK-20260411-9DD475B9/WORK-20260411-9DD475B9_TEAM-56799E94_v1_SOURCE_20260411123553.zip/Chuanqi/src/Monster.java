public class Monster {
    private String name;
    public int blood;
    public int attack;
    public int defence;

    public Monster(int attack, int blood, int defence, String name) {
        this.attack = attack;
        this.blood = blood;
        this.defence = defence;
        this.name = name;
    }

    public void Attack(Character character){
        int damage = this.attack - character.defence;
        if(damage < 0){
            damage = 0;
        }
        character.blood = character.blood -  damage;
        System.out.println(getName()+"造成了"+damage+"点伤害"+character.getName()+"还剩"+character.blood+"生命值");
    }

    public boolean isAlive() {
        return blood > 0;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return getName() + "\n"+
                "攻击力=" + attack +
                ", 血量=" + blood +
                ", 防御力=" + defence;
    }
}
