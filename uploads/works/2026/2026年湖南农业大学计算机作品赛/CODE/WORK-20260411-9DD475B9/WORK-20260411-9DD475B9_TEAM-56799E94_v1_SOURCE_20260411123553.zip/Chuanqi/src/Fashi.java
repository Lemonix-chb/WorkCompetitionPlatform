import java.util.Random;

public class Fashi extends Character{
    public Fashi(String name) {
        super(50, 100, 30, name);
    }

    @Override
    public void skill() {
        Random rand = new Random();
        double multiplier = 1;
        int addattack = rand.nextInt(10)+10;
        int x = rand.nextInt(100);
        if(x<10){
            multiplier = 2.0;
            System.out.println("法师触发暴击！攻击力翻倍！");
        }
        else if(x<30){
            multiplier = 1.5;
            System.out.println("法师触发强力攻击！攻击力提升50%%！");
        }
        else if(x<0){
            multiplier = 1.2;
            System.out.println("法师触发强力攻击！攻击力提升20%%！");
        }
        addattack = (int)(addattack*multiplier);
        attack = attack+addattack;
        System.out.println(getName()+"使用技能，临时增加"+addattack+"点攻击力！");
    }

    @Override
    public String toString() {
        return getName() + "\n"+
                "攻击力=" + attack +
                ", 血量=" + blood +
                ", 防御力=" + defence;
    }
}
