public abstract class Character {
    private String name;
    public int attack;
    public int defence;
    public int blood;
    public Treasure treasure;

    public Character(){
    }

    public Character(int attack, int blood, int defence, String name) {
        this.attack = attack;
        this.blood = blood;
        this.defence = defence;
        this.name = name;
    }

    public abstract void skill();

    public void Attack(Monster monster){
        int damage = attack-monster.defence;
        if(damage < 0){
            damage = 0;
        }
        monster.blood = monster.blood-damage;
        System.out.println(getName()+"造成了"+damage+"点伤害"+monster.getName()+"还剩"+monster.blood+"生命值");

    }

    public boolean isAlive() {
        return blood > 0;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
