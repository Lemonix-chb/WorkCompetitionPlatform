public class Treasure {
    private String name;
    private int attack;
    private int defence;
    private int blood;

    public Treasure(String name, int attack, int defence, int blood) {
        this.name = name;
        this.attack = attack;
        this.defence = defence;
        this.blood = blood;
    }

    public void apply(Character character) {
        character.attack += this.attack;
        character.defence += this.defence;
        character.blood += this.blood;
        System.out.printf("%s装备了%s！属性提升：攻击+%d, 防御+%d, 生命+%d%n",
                character.getName(), name, attack, defence, blood);
    }
    public String getName() {
        return name;
    }
    public int getAttack() {
        return attack;
    }
    public int getDefence() {
        return defence;
    }
    public int getHealth() {
        return blood;
    }
}
