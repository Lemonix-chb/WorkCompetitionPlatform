import java.util.Random;
import java.util.Scanner;

public class Game {
    public int level=1;
    public Character player;
    public void CreateCharactor(){
        System.out.println("请选择角色：");
        System.out.println("1. 战士");
        System.out.println("2. 法师");
        System.out.print("你的选择：");
        Scanner sc = new Scanner(System.in);
        int choice = sc.nextInt();
        sc.nextLine();
        System.out.print("请输入角色名称：");
        String name = sc.nextLine();
        while (true) {
            if (choice == 1) {
                player = new Zhanshi(name);
                break;
            } else if (choice == 2) {
                player = new Fashi(name);
                break;
            } else
                continue;
        }
        System.out.println("角色创建成功！");
        printPlayerInfo();
    }

    public Monster createMonster() {
        switch (level) {
            case 1:
                return new Monster(60, 120, 10, "钉耙猫");
            case 2:
                return new Monster(80, 200, 30, "骷髅战将");
            case 3:
                return new Monster(100, 300,50 , "祖玛教主");
            default: return null;
        }
    }

    public Treasure getTreasure() {
        Random rand = new Random();
        double chance = rand.nextDouble();

        if (chance < 0.05) {
            return new Treasure("屠龙", 999, 100, 100);
        } else if (chance < 0.3) {
            return new Treasure("龙纹剑", 30, 30, 30);
        } else {
            return new Treasure("魔杖", 10, 10, 10);
        }
    }

    public void printPlayerInfo() {
        System.out.println("=== 角色信息 ===");
        System.out.println(player);
        System.out.println("===============");
    }

    public void printMonsterInfo(Monster monster) {
        System.out.println("=== 怪物信息 ===");
        System.out.println(monster);
        System.out.println("===============");
    }

    public void StartGame() {
        while (level<=3){
            Monster monster = createMonster();
            printMonsterInfo(monster);
            while (player.blood>=0 || monster.blood>=0) {
                System.out.println("遭遇敌袭请选择:");
                System.out.println("1. 攻击");
                System.out.println("2. 技能");
                System.out.println("3. 逃跑");
                System.out.print("你的选择:");
                Scanner sc = new Scanner(System.in);
                int choice = sc.nextInt();
                if (choice == 3) {
                    System.out.println("你选择了逃跑，游戏结束！");
                    return;
                }
                else if (choice == 1) {
                    player.Attack(monster);
                    if(!monster.isAlive()){
                        System.out.println(monster.getName()+"已被击败");
                        Treasure treasure = getTreasure();
                        System.out.println("掉落了"+treasure.getName());
                        treasure.apply(player);
                        level++;
                        break;
                    }
                    monster.Attack(player);
                    if (!player.isAlive()){
                        System.out.println("你已被击败，游戏结束！");
                        return;
                    }
                }
                else if (choice == 2) {
                    player.skill();
                    monster.Attack(player);
                }
                printPlayerInfo();
                printMonsterInfo(monster);
            }

        }
        System.out.println("恭喜你通关了所有关卡！");
    }
}
