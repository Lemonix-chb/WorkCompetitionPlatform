import java.util.Random;

public class Zhanshi extends Character{

    public Zhanshi(String name) {
        super(30,200,50,name);
    }

    int maxblood=blood;
    @Override
    public void skill() {
        Random rand = new Random();
        int adddefence = rand.nextInt(10)+10;
        if(this.blood< maxblood*0.5) {
            adddefence = adddefence * 2;
            System.out.println("战士生命值低于50%%，防御提升效果翻倍！");
        }
        defence += adddefence;
        System.out.println(getName()+"使用技能，临时增加"+adddefence+"点防御力！");

    }

    @Override
    public String toString() {
        return getName() + "\n"+
                "攻击力=" + attack +
                ", 血量=" + blood +
                ", 防御力=" + defence;
    }
}
